package control;

import javax.servlet.annotation.WebServlet;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;

import javax.servlet.*;
import javax.servlet.http.*;

import model.ClienteDAO;
import model.beans.clienteBean;

public class Login2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final int ADMIN = 0;
    public static final int REGISTRATO = 1;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        try {
            String redirectedPage;
            req.login(username, password);
            int tipoUtente = checkUser(username, toHash(password));
            ClienteDAO ClienteDAO = new ClienteDAO();
            clienteBean clienteBean = ClienteDAO.leggiCliente(username);

            req.getSession().setAttribute("cliente", clienteBean);

            switch (tipoUtente) {
                case ADMIN:
                    req.getSession().setAttribute("tipoUtente", ADMIN);
                    redirectedPage = "/catalogo.jsp";
                    break;
                case REGISTRATO:
                    req.getSession().setAttribute("tipoUtente", REGISTRATO);
                    redirectedPage = "/catalogo.jsp";
                    break;
                default:
                    redirectedPage = "/Login.jsp";
               /* send Redirect non funziona */
               RequestDispatcher rd = getServletContext().getRequestDispatcher(redirectedPage);
               rd.forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private int checkUser(String username, String password) throws SQLException {
        ClienteDAO ClienteDAO = new ClienteDAO();
        clienteBean clienteBean = ClienteDAO.leggiCliente(username);

        if (clienteBean == null || !(clienteBean.getPw().equals(password)))
            return -1;
        else { return 0;
           /* Inserire codice per controllare se l'utente � un admin*/     
        }
    }
    private String toHash(String password) {		//metodo per criptare la password
    	String hashString = null;
    	try {
    		java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-512");
    		byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
    		hashString = "";
    		for (int i = 0; i < hash.length; i++) {
    			hashString += Integer.toHexString(
    					(hash[i] & 0xFF) | 0x100).toLowerCase().substring(1,3); 
    		}
    	} catch (java.security.NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
    	return hashString;
    }
}
