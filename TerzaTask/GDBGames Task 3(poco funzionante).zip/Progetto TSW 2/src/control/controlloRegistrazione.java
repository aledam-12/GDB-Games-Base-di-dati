package control;

import java.nio.charset.StandardCharsets;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.ClienteDAO;
import model.beans.clienteBean;

@WebServlet("/controlloRegistrazione")
public class controlloRegistrazione extends HttpServlet {
	public controlloRegistrazione () {
		super();
	}
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
		clienteBean cliente = new clienteBean();
		ClienteDAO cdao = new ClienteDAO();
		cliente.setNome(request.getParameter("nome"));
		cliente.setCognome(request.getParameter("cognome"));
		cliente.setVia(request.getParameter("Via"));
		cliente.setCivico(Integer.parseInt(request.getParameter("NCivico")));
		cliente.setCitta(request.getParameter("citt�"));
		cliente.setCap(Integer.parseInt(request.getParameter("cap")));
		cliente.setProvincia((request.getParameter("provincia")));
		cliente.setEmail(request.getParameter("emailCliente"));
		cliente.setPw(toHash(request.getParameter("pwCliente")));
		try {
			if (cdao.isRegistrato(cliente)) cdao.inserisciCliente(cliente);
			RequestDispatcher rd = request.getServletContext().getRequestDispatcher("/Login.jsp");
			request.setAttribute("stato", cdao.isRegistrato(cliente)); //stato per i feedback
			rd.forward(request, response);
			} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
    private String toHash(String password) {		//metodo per criptare la password
    	String hashString = null;
    	try {
    		java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-512");
    		byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
    		hashString = "";
    		for (int i = 0; i < hash.length; i++) {
    			hashString += Integer.toHexString(
    					(hash[i] & 0xFF) | 0x100).toLowerCase().substring(1,3); 
    		}
    	} catch (java.security.NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
    	return hashString;
    }
}
