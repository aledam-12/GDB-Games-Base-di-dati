package control;
import model.OrdineCopia;

import model.AcquistoDAO;
import model.ProdottiDAO;
import model.beans.acquistoBean;
import model.beans.clienteBean;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;

@WebServlet("/Checkout")
public class Checkout extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Carrello carrelloCheckout = (Carrello) req.getSession().getAttribute("carrello");
        clienteBean cliente = (clienteBean) req.getSession().getAttribute("cliente");	//verr� usato quando viene sviluppata la logica del login
        float prezzoTot = (float) carrelloCheckout.getPrezzoTotale();

//carrello checkout � l'istanza di controlloCarrello

        acquistoBean acquistoBean = new acquistoBean();
        acquistoBean.setemailcliente("cliente1@example.com"); //da modificare in occasione della task del login
        acquistoBean.setPrezzoTotale(prezzoTot);
        acquistoBean.setdataAcquisto(LocalDate.now());
        acquistoBean.setCap(Integer.parseInt(req.getParameter("cap-spedizione")));
        acquistoBean.setnCarta(Integer.parseInt(req.getParameter("numCarta")));
        acquistoBean.setVia(req.getParameter("via-spedizione"));
        acquistoBean.setCitta(req.getParameter("citta-spedizione"));
        AcquistoDAO ordineDAO = new AcquistoDAO();
        ProdottiDAO pdao = new ProdottiDAO();
        try {
        	ordineDAO.inserisciOrdine(acquistoBean);
        	req.getSession().removeAttribute("carrello");
        	RequestDispatcher rd = req.getServletContext().getRequestDispatcher("/acquisto.jsp");
            rd.forward(req, resp);
            for (OrdineCopia o : carrelloCheckout.viewCart()) {
            	int temp = o.getQuantit�();
            	for (int i = 0; i < temp; i++) {
            		pdao.UpdateCopia(o, acquistoBean);
            }
          }
        }
        catch (Exception e) {e.printStackTrace();}
    }
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req,resp);
	}
}