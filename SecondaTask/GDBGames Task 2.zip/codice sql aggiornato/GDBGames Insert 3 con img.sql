use gdbgames;
INSERT INTO videogioco (titolo, descrizione, pegi, img) 
VALUES 
("Assassin's Creed", "Entra nella pelle di un assassino e affronta avventure epiche in diversi periodi storici.", 18, NULL),
("Assassin's Creed III", "Vivi le avventure di Connor, un guerriero nativo americano durante la Rivoluzione Americana.", 18, NULL),
("Assassin's Creed Valhalla", "Guida Eivor e il suo clan vichingo nel tentativo di insediarsi in Inghilterra durante l'era dei vichinghi.", 18, NULL),
('Far Cry 3', "Sopravvivi su un'isola tropicale piena di pericoli e diventa il peggior incubo dei tuoi nemici.", 18, NULL),
('Far Cry 6', 'Unisciti alla resistenza per rovesciare un dittatore nel paradiso tropicale di Yara.', 18, NULL),
('God of War Ragnarok', 'Accompagna Kratos e suo figlio Atreus in un viaggio epico attraverso le terre della mitologia nordica.', 18, NULL),
('Horizon Forbidden West', 'Esplora un mondo post-apocalittico popolato da creature meccaniche in un''avventura emozionante.', 16, NULL),
('Rainbow Six Siege', 'Partecipa a intense battaglie tattiche multigiocatore in questo sparatutto in prima persona.', 18, NULL),
('Sekiro: Shadows Die Twice', 'Sfida la morte nei panni di un guerriero shinobi e affronta avversità implacabili in un Giappone del XVI secolo.', 18, NULL);

INSERT INTO copia (stato, percIva, prezzo, codiceAcquisto, titoloVideogioco, nomeConsole) 
VALUES 
(false, 22.00, 49.99, NULL, "Assassin's Creed", 'PlayStation 4'),
(false, 22.00, 49.99, null, "Assassin's Creed III", 'Xbox One'),
(false, 22.00, 59.99, null, "Assassin's Creed Valhalla", 'PlayStation 5'),
(false, 22.00, 29.99, null, 'Far Cry 3', 'PC'),
(false, 22.00, 59.99, null, 'Far Cry 6', 'Xbox Series X'),
(false, 22.00, 69.99, null, 'God of War Ragnarok', 'PlayStation 5'),
(false, 22.00, 69.99, null, 'Horizon Forbidden West', 'PlayStation 5'),
(false, 22.00, 39.99, null, 'Rainbow Six Siege', 'PC'),
(false, 22.00, 49.99, null, 'Sekiro: Shadows Die Twice', 'PlayStation 4');

INSERT INTO distinzione (titoloVideogioco, nomeGenere) 
VALUES 
("Assassin's Creed", 'Azione'),
("Assassin's Creed III", 'Azione'),
("Assassin's Creed Valhalla", 'Azione'),
('Far Cry 3', 'Sparatutto'),
('Far Cry 6', 'Sparatutto'),
('God of War Ragnarok', 'Azione'),
('Horizon Forbidden West', 'Azione'),
('Rainbow Six Siege', 'Sparatutto'),
('Sekiro: Shadows Die Twice', 'Azione');

