use gdbgames;
-- Inserimento dei clienti
INSERT INTO cliente (email, nome, cognome, pw)
VALUES 
('cliente1@example.com', 'Mario', 'Rossi', 'hashed_password1'),
('cliente2@example.com', 'Luigi', 'Verdi', 'hashed_password2'),
('cliente3@example.com', 'Giovanna', 'Bianchi', 'hashed_password3');

-- Inserimento degli acquisti
INSERT INTO acquisto (emailCliente, ncarta, dataAcquisto, via, cap, città, prezzoTotale) 
VALUES 
('cliente1@example.com', 1234567890123456, '2024-05-01', 'Via Roma 1', 12345, 'Roma', 59.99),
('cliente2@example.com', 9876543210987654, '2024-05-02', 'Via Milano 2', 54321, 'Milano', 39.99),
('cliente3@example.com', 1111222233334444, '2024-05-03', 'Via Napoli 3', 67890, 'Napoli', 49.99);

-- Inserimento dei generi
INSERT INTO genere (nome) 
VALUES 
('Azione'),
('Avventura'),
('Sport');

-- Inserimento delle console
INSERT INTO console (nome) 
VALUES 
('PlayStation 5'),
('Xbox Series X'),
('Nintendo Switch');

-- Inserimento dei videogiochi
INSERT INTO videogioco (titolo, descrizione, pegi, img) 
VALUES 
('GTA V', 'Gioco di azione open world', 18, NULL),
('The Legend of Zelda: Breath of the Wild', 'Gioco di avventura epico', 12, NULL),
('FIFA 24', 'Simulazione calcistica', 3, NULL);

-- Inserimento delle distinzioni (associazione tra videogiochi e generi)
INSERT INTO distinzione (titoloVideogioco, nomeGenere) 
VALUES 
('GTA V', 'Azione'),
('GTA V', 'Avventura'),
('FIFA 24', 'Sport');

-- Inserimento delle copie
INSERT INTO copia (stato, percIva, prezzo, codiceAcquisto, titoloVideogioco, nomeConsole) 
VALUES 
(true, 22.0, 49.99, 1, 'GTA V', 'PlayStation 5'),
(true, 22.0, 59.99, 2, 'The Legend of Zelda: Breath of the Wild', 'Nintendo Switch'),
(true, 22.0, 39.99, 3, 'FIFA 24', 'Xbox Series X');

-- Inserimento dei reclami
INSERT INTO reclamo (dataReclamo, titolo, contenuto, emailCliente) 
VALUES 
('2024-05-02', 'Problema con il salvataggio', 'Non riesco a salvare il mio progresso nel gioco.', 'cliente1@example.com'),
('2024-05-03', 'Grafica scadente', 'La grafica del gioco è molto deludente.', 'cliente2@example.com');
