-- Inserimento dei dati per la tabella cliente
INSERT INTO cliente (email, nome, cognome, pw) VALUES
('cliente1@example.com', 'NomeCliente1', 'CognomeCliente1', 'hash_password1'),
('cliente2@example.com', 'NomeCliente2', 'CognomeCliente2', 'hash_password2'),
('cliente3@example.com', 'NomeCliente3', 'CognomeCliente3', 'hash_password3');

-- Inserimento dei dati per la tabella acquisto
INSERT INTO acquisto (emailCliente, ncarta, dataAcquisto, via, cap, città, prezzoTotale) VALUES
('cliente1@example.com', 1234567890123456, '2024-04-24', 'Via dei Clienti 1', 12345, 'Città1', 50.00),
('cliente2@example.com', 2345678901234567, '2024-04-23', 'Via dei Clienti 2', 23456, 'Città2', 60.00),
('cliente3@example.com', 3456789012345678, '2024-04-22', 'Via dei Clienti 3', 34567, 'Città3', 70.00);

-- Inserimento dei dati per la tabella genere
INSERT INTO genere (nome) VALUES
('Azione'),
('Avventura'),
('Sport');

-- Inserimento dei dati per la tabella console
INSERT INTO console (nome) VALUES
('PlayStation 5'),
('Xbox Series X'),
('Nintendo Switch');

-- Inserimento dei dati per la tabella videogioco
INSERT INTO videogioco (titolo, descrizione, pegi) VALUES
('TitoloVideogioco1', 'Descrizione Videogioco 1', 12),
('TitoloVideogioco2', 'Descrizione Videogioco 2', 16),
('TitoloVideogioco3', 'Descrizione Videogioco 3', 18);

-- Inserimento dei dati per la tabella distinzione
INSERT INTO distinzione (titoloVideogioco, nomeGenere) VALUES
('TitoloVideogioco1', 'Azione'),
('TitoloVideogioco2', 'Avventura'),
('TitoloVideogioco3', 'Sport');

-- Inserimento dei dati per la tabella copia
INSERT INTO copia (stato, percIva, prezzo, codiceAcquisto, titoloVideogioco, nomeConsole) VALUES
(TRUE, 22.00, 40.00, 1, 'TitoloVideogioco1', 'PlayStation 5'),
(TRUE, 22.00, 50.00, 2, 'TitoloVideogioco2', 'Xbox Series X'),
(TRUE, 22.00, 60.00, 3, 'TitoloVideogioco3', 'Nintendo Switch');

-- Inserimento dei dati per la tabella reclamo
INSERT INTO reclamo (dataReclamo, titolo, contenuto, emailCliente) VALUES
('2024-04-24', 'Problema con il gioco', 'Il gioco non si avvia correttamente', 'cliente1@example.com'),
('2024-04-23', 'Articolo danneggiato', 'La confezione è arrivata danneggiata', 'cliente2@example.com'),
('2024-04-22', 'Assistenza scadente', 'Il servizio clienti non risponde alle mie richieste', 'cliente3@example.com');
