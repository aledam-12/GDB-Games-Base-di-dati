package modello;
import beans.copiaBean;
import java.sql.SQLException;
import java.util.ArrayList;

public interface Prodotti
{
	public ArrayList<copiaBean> leggiTutteCopie (String sort) throws SQLException;
	public copiaBean leggiCopia(int codice) throws SQLException;
}