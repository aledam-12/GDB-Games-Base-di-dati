package modello;
import beans.videogiocoBean;
import beans.copiaBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProdottiDAO implements Prodotti {
	public synchronized ArrayList<copiaBean> leggiTutteCopie (String sort) throws SQLException{
		String sql = "SELECT * FROM copia WHERE stato = 0";
		ArrayList <copiaBean> copie = new ArrayList <>();
		Connection conn = null;
		PreparedStatement ps = null;
		if (sort != null && !sort.equals("")) {
			sql += " ORDER BY " + sort;
		}	
		try { conn = connessionePool.getConnection(); 
		ps = conn.prepareStatement(sql); 
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			copiaBean copia = new copiaBean();
			copia.setCodiceCopia(rs.getInt("codiceCopia"));
			copia.setTitoloVideogioco(rs.getString("titoloVideogioco"));
			copia.setPercIva(rs.getFloat("percIva"));
			copia.setPrezzo(rs.getFloat("prezzo"));
			copia.setNomeConsole(rs.getNString("nomeConsole"));
			copie.add(copia);
		}
		}
		finally {
			try {
				if (ps != null)
					ps.close();
			} finally {
				connessionePool.rilasciaConnessione(conn);
			}
		}
		return copie;
}	
	public synchronized copiaBean leggiCopia(int codice) throws SQLException {
		copiaBean copia = new copiaBean();
		Connection conn = null;
		PreparedStatement ps = null;
		String SQL = "SELECT * FROM copia WHERE codiceCopia = ?";
		try { conn = connessionePool.getConnection();
		ps = conn.prepareStatement(SQL);
		ps.setInt(1, codice);
		ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				copia.setCodiceCopia(codice);
				copia.setNomeConsole(rs.getString("nomeConsole"));
				copia.setPercIva(rs.getFloat("percIva"));
				copia.setPrezzo(rs.getFloat("prezzo"));
				copia.setTitoloVideogioco(rs.getString("titoloVideogioco"));
			}
		}
		finally {
			try {
				if (ps != null)
					ps.close();
			} finally {
				connessionePool.rilasciaConnessione(conn);
			}
		} 
		return copia;
	}
	public synchronized videogiocoBean leggiVideogioco(String titolo) throws SQLException {
		videogiocoBean videogioco = new videogiocoBean();
		Connection conn = null;
		PreparedStatement ps = null;
		String SQL = "SELECT * FROM videogioco WHERE titolo = ?";
		try { conn = connessionePool.getConnection();
		ps = conn.prepareStatement(SQL);
		ps.setString(1, titolo);
		ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				videogioco.setDescrizione(rs.getString("descrizione"));
				videogioco.setPegi(rs.getInt("pegi"));
				videogioco.setTitolo(titolo);
			}
		}
		finally {
			try {
				if (ps != null)
					ps.close();
			} finally {
				connessionePool.rilasciaConnessione(conn);
			}
		} 
		return videogioco;
	}
}